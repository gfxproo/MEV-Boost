package main

import "github.com/flashbots/mev-boost/cli"

func main() {
	cli.Main()
}
